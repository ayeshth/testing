using ImportProcess.Models;
using Azure.AI.FormRecognizer.DocumentAnalysis;

namespace AzureFormRecognizerApp.Services
{
    public interface IFormRecognizerService
    {
        Task<DocumentAnalysisResult> AnalyzeDocumentAsync(IFormFile file, string modelId);
        Task<AnalyzeResult> GetRawAnalyzeResultAsync(IFormFile file, string modelId = "prebuilt-read");
        Task<InvoiceAnalysisResult> AnalyzeInvoiceAsync(IFormFile file);
        Task<List<List<List<string>>>> ExtractTablesAsync(IFormFile file);
    }

    public class DocumentAnalysisResult
    {
        public string Content { get; set; } = string.Empty;
        public List<DocumentField> Fields { get; set; } = new();
        public List<DocumentTable> Tables { get; set; } = new();
    }

    public class InvoiceAnalysisResult
    {
        public DocumentAnalysisResult InvoiceResult { get; set; } = new();
        public DocumentAnalysisResult FullTextResult { get; set; } = new();
    }

    public class DocumentField
    {
        public string Name { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
        public float Confidence { get; set; }
    }

    public class DocumentTable
    {
        public int RowCount { get; set; }
        public int ColumnCount { get; set; }
        public List<List<string>> Cells { get; set; } = new();
    }
}
