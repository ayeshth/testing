using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ImportProcess.Models;
using ImportProcess.Services;

namespace ImportProcess.Controllers
{
    [ApiController]
    [Route("api/BankStatementOCR/[controller]")]
    public class CommercialBankStatementController : ControllerBase
    {
        private readonly ICommercialBankStatementService _service;

        public CommercialBankStatementController(ICommercialBankStatementService service)
        {
            _service = service;
        }

        // POST: /api/CommercialBankStatement/extract
        [HttpPost("extract")]
        public async Task<ActionResult<List<CommercialBankRecord>>> Extract([FromForm] IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("File is required");

            var records = await _service.ExtractAsync(file);

            // As you requested: return the records directly as JSON (no envelope)
            // Each record contains date, sourceDocNo, amount, amountStatus (+ particularsTag)
            return Ok(records);
        }
    }
}
