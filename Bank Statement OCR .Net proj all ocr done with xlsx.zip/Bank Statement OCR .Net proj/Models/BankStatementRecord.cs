namespace ImportProcess.Models
{
    public class BankStatementRecord
    {
        public DateTime TxnDate { get; set; }
        public string? SourceDocNo { get; set; }
        public decimal Amount { get; set; }
        public string AmountStatus { get; set; } // e.g. CASH DEPOSIT / DIRECT DEPOSIT
    }
}
