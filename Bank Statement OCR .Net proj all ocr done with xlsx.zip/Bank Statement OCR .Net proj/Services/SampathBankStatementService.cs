using ClosedXML.Excel;
using ImportProcess.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;

namespace ImportProcess.Services
{
    public class SampathBankStatementService : ISampathBankStatementService
    {
        public async Task<List<SampathBankTransaction>> ExtractTransactionsAsync(IFormFile file)
        {
            var transactions = new List<SampathBankTransaction>();

            if (file == null || file.Length == 0)
                throw new ArgumentException("Invalid file");

            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);
                stream.Position = 0;

                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(1);

                    // Find header row containing "Txn Date"
                    int headerRow = -1;
                    for (int r = 1; r <= 10; r++)
                    {
                        var cellText = worksheet.Cell(r, 1).GetString().Trim();
                        if (string.Equals(cellText, "Txn Date", StringComparison.OrdinalIgnoreCase))
                        {
                            headerRow = r;
                            break;
                        }
                    }

                    if (headerRow == -1)
                        throw new Exception("Could not find header row with 'Txn Date'");

                    int row = headerRow + 1;

                    // Loop through transaction rows
                    while (!worksheet.Cell(row, 1).IsEmpty())
                    {
                        try
                        {
                            // Txn Date
                            string dateText = worksheet.Cell(row, 1).GetString().Trim();
                            if (!DateTime.TryParseExact(dateText, "dd/MM/yyyy", 
                                CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime txnDate))
                            {
                                Console.WriteLine($"Row {row}: Invalid date format '{dateText}', skipping");
                                row++;
                                continue;
                            }

                            // Source Doc No
                            var sourceDocNo = worksheet.Cell(row, 2).GetString().Trim();

                            // CR/DR column → AmountStatus
                            var amountStatus = worksheet.Cell(row, 5).GetString().Trim();

                            // Amount
                            string amountText = worksheet.Cell(row, 6).GetString().Trim().Replace(",", "");
                            if (!decimal.TryParse(amountText, NumberStyles.Any, 
                                CultureInfo.InvariantCulture, out decimal amount))
                            {
                                Console.WriteLine($"Row {row}: Invalid amount '{amountText}', setting amount = 0");
                                amount = 0m;
                            }

                            // Add only required columns
                            transactions.Add(new SampathBankTransaction
                            {
                                TxnDate = txnDate,
                                SourceDocNo = sourceDocNo,
                                Amount = amount,
                                AmountStatus = amountStatus
                            });
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Row {row}: Exception {ex.Message}, skipping");
                        }
                        row++;
                    }
                }
            }

            return transactions;
        }
    }
}
