using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using ImportProcess.Services;

namespace ImportProcess.Controllers
{
    [ApiController]
[Route("api/BankStatementOCR/[controller]")]
public class SampathBankStatementController : ControllerBase
{
    private readonly ISampathBankStatementService _service;

    public SampathBankStatementController(ISampathBankStatementService service)
    {
        _service = service;
    }

    [HttpPost("extract")]
    public async Task<IActionResult> Extract([FromForm] IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new { success = false, errorMessage = "File is empty" });

        try
        {
            var transactions = await _service.ExtractTransactionsAsync(file);

            return Ok(new { success = true, data = transactions });
        }
        catch (Exception ex)
        {
            return BadRequest(new { success = false, errorMessage = ex.Message });
        }
    }
}

}
