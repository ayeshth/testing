using Microsoft.AspNetCore.Http;
using ImportProcess.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ImportProcess.Services
{
    public interface ISampathBankStatementService
    {
        Task<List<SampathBankTransaction>> ExtractTransactionsAsync(IFormFile file);
    }
}
