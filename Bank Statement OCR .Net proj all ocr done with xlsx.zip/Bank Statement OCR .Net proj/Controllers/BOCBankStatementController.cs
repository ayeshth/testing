using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ImportProcess.Models;
using ImportProcess.Services;

namespace ImportProcess.Controllers
{
    [ApiController]
    [Route("api/BankStatementOCR/[controller]")]
    public class BOCBankStatementController : ControllerBase
    {
        private readonly IBOCBankStatementService _bocService;
        private readonly ILogger<BOCBankStatementController> _logger;

        public BOCBankStatementController(IBOCBankStatementService bocService, ILogger<BOCBankStatementController> logger)
        {
            _bocService = bocService;
            _logger = logger;
        }

        [HttpPost("extract")]
        public async Task<IActionResult> ExtractBOCStatement([FromForm] IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            try
            {
                var records = await _bocService.ExtractAsync(file);
                return Ok(records);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting BOC bank statement.");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
