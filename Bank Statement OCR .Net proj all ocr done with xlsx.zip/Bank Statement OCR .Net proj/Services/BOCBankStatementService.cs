using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ImportProcess.Models;
using AzureFormRecognizerApp.Services;

namespace ImportProcess.Services
{
    public class BOCBankStatementService : IBOCBankStatementService
    {
        private readonly IFormRecognizerService _ocr;
        private readonly ILogger<BOCBankStatementService> _logger;

        public BOCBankStatementService(IFormRecognizerService ocr, ILogger<BOCBankStatementService> logger)
        {
            _ocr = ocr;
            _logger = logger;
        }

        public async Task<List<BOCBankRecord>> ExtractAsync(IFormFile file)
        {
            var tables = await _ocr.ExtractTablesAsync(file);
            var records = new List<BOCBankRecord>();

            foreach (var table in tables)
            {
                if (table.Count == 0) continue;

                // Identify header row
                int headerRowIdx = -1;
                for (int r = 0; r < table.Count; r++)
                {
                    var rowNorm = table[r].Select(c => NormalizeHeader(c)).ToList();
                    if (rowNorm.Contains("DATE") && (rowNorm.Contains("PARTICULARS") || rowNorm.Contains("DESCRIPTION")) && 
                        (rowNorm.Contains("RECEIPTS") || rowNorm.Contains("PAYMENTS") || rowNorm.Contains("WITHDRAWALS") || rowNorm.Contains("DEPOSITS")))
                    {
                        headerRowIdx = r;
                        break;
                    }
                }
                if (headerRowIdx < 0) continue;

                var header = table[headerRowIdx];
                int colDate = FindCol(header, "DATE");
                int colParticulars = FindCol(header, "PARTICULARS", "DESCRIPTION", "DETAILS");
                int colReceipts = FindCol(header, "RECEIPTS", "DEPOSITS", "CREDIT");
                int colPayments = FindCol(header, "PAYMENTS", "WITHDRAWALS", "DEBIT");

                string? carryDateIso = null;

                for (int r = headerRowIdx + 1; r < table.Count; r++)
                {
                    var row = table[r];
                    string dateRaw = GetCell(row, colDate);
                    string particularsRaw = GetCell(row, colParticulars);
                    string receiptsRaw = GetCell(row, colReceipts);
                    string paymentsRaw = GetCell(row, colPayments);

                    bool hasDate = TryParseDate(dateRaw, out var dateIso);
                    bool hasReceipts = TryParseAmount(receiptsRaw, out var receiptsAmt);
                    bool hasPayments = TryParseAmount(paymentsRaw, out var paymentsAmt);

                    if (hasDate) carryDateIso = dateIso;

                    // Process based on which amount column has value
                    if (hasReceipts || hasPayments)
                    {
                        decimal amount = 0m;
                        string amountStatus = null;

                        if (hasReceipts && receiptsAmt > 0)
                        {
                            amount = receiptsAmt;
                            amountStatus = "CR"; // Credit for receipts
                        }
                        else if (hasPayments && paymentsAmt > 0)
                        {
                            amount = paymentsAmt;
                            amountStatus = "DR"; // Debit for payments
                        }

                        // Only add record if we have a valid amount and status
                        if (amount > 0 && !string.IsNullOrEmpty(amountStatus))
                        {
                            records.Add(new BOCBankRecord
                            {
                                Date = carryDateIso ?? "",
                                SourceDocNo = !string.IsNullOrWhiteSpace(particularsRaw) ? particularsRaw : null,
                                Amount = amount,
                                AmountStatus = amountStatus
                            });
                        }
                    }
                }
            }

            return records;
        }

        // Helpers
        private static string GetCell(List<string> row, int idx)
            => (idx >= 0 && idx < row.Count) ? (row[idx] ?? "").Trim() : "";

        private static int FindCol(List<string> header, params string[] targets)
        {
            for (int i = 0; i < header.Count; i++)
            {
                string normalizedHeader = NormalizeHeader(header[i]);
                foreach (var target in targets)
                {
                    if (normalizedHeader == target.ToUpperInvariant())
                        return i;
                }
            }
            return -1;
        }

        private static string NormalizeHeader(string? s)
        {
            s ??= "";
            s = Regex.Replace(s, @"\s+", " ").Trim();
            s = s.ToUpperInvariant();
            return s;
        }

        private static bool TryParseDate(string input, out string iso)
        {
            iso = "";
            if (string.IsNullOrWhiteSpace(input)) return false;

            input = input.Trim();

            // Case 1: Excel numeric date
            if (double.TryParse(input, out double oaDate))
            {
                try
                {
                    var dt = DateTime.FromOADate(oaDate);
                    iso = dt.ToString("yyyy-MM-dd");
                    return true;
                }
                catch { }
            }

            // Case 2: Full date formats
            string[] fullFormats = { "dd/MM/yyyy", "dd/MM/yy", "dd-MMM-yyyy", "dd-MMM-yy", "MM/dd/yyyy", "MM/dd/yy" };
            if (DateTime.TryParseExact(input, fullFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dtFull))
            {
                iso = dtFull.ToString("yyyy-MM-dd");
                return true;
            }

            // Case 3: Short date without year (dd/MM or dd-MM) → assume current year
            string[] shortFormats = { "dd/MM", "dd-MM", "MM/dd" };
            if (DateTime.TryParseExact(input, shortFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dtShort))
            {
                var assumed = new DateTime(DateTime.Now.Year, dtShort.Month, dtShort.Day);
                iso = assumed.ToString("yyyy-MM-dd");
                return true;
            }

            // Case 4: Let normal parsing try (covers edge cases)
            if (DateTime.TryParse(input, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dtParsed))
            {
                iso = dtParsed.ToString("yyyy-MM-dd");
                return true;
            }

            return false;
        }

        private static bool TryParseAmount(string input, out decimal value)
        {
            value = 0m;
            if (string.IsNullOrWhiteSpace(input)) return false;

            var s = input.Replace(",", "").Trim();
            
            // Remove currency symbols and other non-numeric characters (except decimal point and minus sign)
            s = Regex.Replace(s, @"[^\d\.\-]", "");
            
            // Handle cases where there might be multiple decimal points
            if (s.Count(c => c == '.') > 1)
            {
                // Take only the last decimal point and everything after it
                int lastDecimalIndex = s.LastIndexOf('.');
                s = s.Substring(0, lastDecimalIndex).Replace(".", "") + s.Substring(lastDecimalIndex);
            }

            if (decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var v))
            {
                value = Math.Abs(v); // Always take absolute value, we'll determine DR/CR from column
                return value != 0m;
            }
            return false;
        }
    }
}