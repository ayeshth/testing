using System.ComponentModel.DataAnnotations;

namespace ImportProcess.Models
{
    public class LCAdviceExtractionRequest
    {
        [Required]
        public IFormFile File { get; set; }
        
        [Required]
        public string ImportRequestNumber { get; set; }
        
        [Required]
        public string Company { get; set; }
        
        [Required]
        public string Bank { get; set; }
        
        // Optional properties for additional context
        public string DocumentType { get; set; } = "LC_ADVICE";
        
        public DateTime? RequestDate { get; set; } = DateTime.UtcNow;
        
        public string UserId { get; set; }
        
        // For any additional parameters that might be needed
        public Dictionary<string, object> AdditionalParameters { get; set; } = new Dictionary<string, object>();
        
        // Validation method
        public bool IsValid()
        {
            return File != null && 
                   !string.IsNullOrEmpty(ImportRequestNumber) && 
                   !string.IsNullOrEmpty(Company) && 
                   !string.IsNullOrEmpty(Bank);
        }
        
        // Supported banks
        public static readonly string[] SupportedBanks = { "SAMPATH", "COMMERCIAL", "SCB", "NDB", "HNB" };
        
        public bool IsBankSupported()
        {
            return SupportedBanks.Contains(Bank?.ToUpperInvariant());
        }
    }
}