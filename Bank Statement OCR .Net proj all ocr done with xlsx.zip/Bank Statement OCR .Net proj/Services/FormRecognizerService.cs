using Azure;
using Azure.AI.FormRecognizer.DocumentAnalysis;
using AzureFormRecognizerApp.Models;
using Microsoft.Extensions.Options;

namespace AzureFormRecognizerApp.Services
{
    public class FormRecognizerService : IFormRecognizerService
    {
        private readonly DocumentAnalysisClient _client;
        private readonly ILogger<FormRecognizerService> _logger;

        public FormRecognizerService(IOptions<AzureFormRecognizerConfig> config, ILogger<FormRecognizerService> logger)
        {
            _logger = logger;
            var credential = new AzureKeyCredential(config.Value.ApiKey);
            _client = new DocumentAnalysisClient(new Uri(config.Value.Endpoint), credential);
        }

        public async Task<DocumentAnalysisResult> AnalyzeDocumentAsync(IFormFile file, string modelId)
        {
            try
            {
                using var stream = file.OpenReadStream();

                var operation = await _client.AnalyzeDocumentAsync(
                    WaitUntil.Completed,
                    modelId,
                    stream);

                var result = operation.Value;

                return new DocumentAnalysisResult
                {
                    Content = result.Content,
                    Fields = ExtractFields(result),
                    Tables = ExtractTables(result)
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error analyzing document with model {ModelId}", modelId);
                throw;
            }
        }

        // Add this method to your existing FormRecognizerService class
        public async Task<AnalyzeResult> GetRawAnalyzeResultAsync(IFormFile file, string modelId = "prebuilt-read")
        {
            try
            {
                using var stream = file.OpenReadStream();
                
                var operation = await _client.AnalyzeDocumentAsync(
                    WaitUntil.Completed, 
                    modelId, 
                    stream);
                    
                return operation.Value;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting raw analyze result with model {ModelId}", modelId);
                throw;
            }
        }

        public async Task<InvoiceAnalysisResult> AnalyzeInvoiceAsync(IFormFile file)
        {
            try
            {
                using var stream1 = file.OpenReadStream();
                using var stream2 = file.OpenReadStream();

                var invoiceOperation = await _client.AnalyzeDocumentAsync(
                    WaitUntil.Completed,
                    "prebuilt-invoice",
                    stream1);

                var readOperation = await _client.AnalyzeDocumentAsync(
                    WaitUntil.Completed,
                    "prebuilt-read",
                    stream2);

                _logger.LogInformation("Document analysis completed successfully");

                return new InvoiceAnalysisResult
                {
                    InvoiceResult = ConvertToDocumentAnalysisResult(invoiceOperation.Value),
                    FullTextResult = ConvertToDocumentAnalysisResult(readOperation.Value)
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error analyzing invoice document");
                throw;
            }
        }

        public async Task<List<List<List<string>>>> ExtractTablesAsync(IFormFile file)
        {
            try
            {
                using var stream = file.OpenReadStream();

                var operation = await _client.AnalyzeDocumentAsync(
                    WaitUntil.Completed,
                    "prebuilt-layout",
                    stream);

                var result = operation.Value;
                var tablesData = new List<List<List<string>>>();

                foreach (var table in result.Tables)
                {
                    var tableMatrix = new List<List<string>>();
                    for (int i = 0; i < table.RowCount; i++)
                    {
                        var row = new List<string>();
                        for (int j = 0; j < table.ColumnCount; j++)
                        {
                            row.Add(string.Empty);
                        }
                        tableMatrix.Add(row);
                    }

                    foreach (var cell in table.Cells)
                    {
                        if (cell.RowIndex < tableMatrix.Count &&
                            cell.ColumnIndex < tableMatrix[cell.RowIndex].Count)
                        {
                            tableMatrix[cell.RowIndex][cell.ColumnIndex] = cell.Content ?? string.Empty;
                        }
                    }

                    tablesData.Add(tableMatrix);
                }

                return tablesData;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting tables from document");
                throw;
            }
        }

        private DocumentAnalysisResult ConvertToDocumentAnalysisResult(AnalyzeResult result)
        {
            return new DocumentAnalysisResult
            {
                Content = result.Content,
                Fields = ExtractFields(result),
                Tables = ExtractTables(result)
            };
        }

        private List<DocumentField> ExtractFields(AnalyzeResult result)
        {
            var fields = new List<DocumentField>();

            foreach (var document in result.Documents)
            {
                foreach (var field in document.Fields)
                {
                    fields.Add(new DocumentField
                    {
                        Name = field.Key,
                        Value = field.Value.Content ?? string.Empty,
                        Confidence = field.Value.Confidence ?? 0
                    });
                }
            }

            return fields;
        }

        private List<DocumentTable> ExtractTables(AnalyzeResult result)
        {
            var tables = new List<DocumentTable>();

            foreach (var table in result.Tables)
            {
                var documentTable = new DocumentTable
                {
                    RowCount = table.RowCount,
                    ColumnCount = table.ColumnCount,
                    Cells = new List<List<string>>()
                };

                for (int i = 0; i < table.RowCount; i++)
                {
                    var row = new List<string>();
                    for (int j = 0; j < table.ColumnCount; j++)
                    {
                        row.Add(string.Empty);
                    }
                    documentTable.Cells.Add(row);
                }

                foreach (var cell in table.Cells)
                {
                    if (cell.RowIndex < documentTable.Cells.Count &&
                        cell.ColumnIndex < documentTable.Cells[cell.RowIndex].Count)
                    {
                        documentTable.Cells[cell.RowIndex][cell.ColumnIndex] = cell.Content ?? string.Empty;
                    }
                }

                tables.Add(documentTable);
            }

            return tables;
        }
    }
}

