using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using ImportProcess.Services;

namespace ImportProcess.Controllers
{
    [ApiController]
    [Route("api/BankStatementOCR")]
    public class BankStatementController : ControllerBase
    {
        private readonly IBOCBankStatementService _bocService;
        private readonly ICommercialBankStatementService _commercialService;
        private readonly ISampathBankStatementService _sampathService;
        private readonly IPeoplesBankStatementService _peoplesService;
        private readonly ISeylanBankStatementService _seylanService; // NEW
        private readonly ILogger<BankStatementController> _logger;

        public BankStatementController(
            IBOCBankStatementService bocService,
            ICommercialBankStatementService commercialService,
            ISampathBankStatementService sampathService,
            IPeoplesBankStatementService peoplesService,
            ISeylanBankStatementService seylanService, // NEW
            ILogger<BankStatementController> logger)
        {
            _bocService = bocService;
            _commercialService = commercialService;
            _sampathService = sampathService;
            _peoplesService = peoplesService;
            _seylanService = seylanService; // NEW
            _logger = logger;
        }

        [HttpPost("extract")]
        public async Task<IActionResult> ExtractBankStatement([FromForm] IFormFile file, [FromForm] string bankName)
        {
            if (file == null || file.Length == 0)
                return BadRequest(new { success = false, errorMessage = "No file uploaded." });

            if (string.IsNullOrEmpty(bankName))
                return BadRequest(new { success = false, errorMessage = "Bank name is required." });

            try
            {
                object result;

                switch (bankName.ToLower())
                {
                    case "boc":
                        var bocRecords = await _bocService.ExtractAsync(file);
                        result = new { success = true, data = bocRecords };
                        break;

                    case "commercial":
                        var commercialRecords = await _commercialService.ExtractAsync(file);
                        result = new { success = true, data = commercialRecords };
                        break;

                    case "sampath":
                        var sampathTransactions = await _sampathService.ExtractTransactionsAsync(file);
                        result = new { success = true, data = sampathTransactions };
                        break;

                    case "peoples":
                        var peoplesTransactions = await _peoplesService.ExtractTransactionsAsync(file);
                        result = new { success = true, data = peoplesTransactions };
                        break;

                    case "seylan": // NEW
                        var seylanTransactions = await _seylanService.ExtractTransactionsAsync(file);
                        result = new { success = true, data = seylanTransactions };
                        break;

                    default:
                        return BadRequest(new
                        {
                            success = false,
                            errorMessage = $"Unsupported bank: {bankName}. Supported banks: boc, commercial, sampath, peoples, seylan"
                        });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error extracting {bankName} bank statement.");
                return StatusCode(500, new
                {
                    success = false,
                    errorMessage = "Internal server error",
                    details = ex.Message
                });
            }
        }
    }
}
