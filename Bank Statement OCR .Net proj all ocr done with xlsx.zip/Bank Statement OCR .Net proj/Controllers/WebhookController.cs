using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebhookReceiver.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        [HttpPost]
        public IActionResult UploadFile(
            [FromForm] IFormFile bl,
            [FromForm] string company,
            [FromForm] string impReqNumber)
        {
            if (bl == null || bl.Length == 0)
            {
                return BadRequest("No file uploaded.");
            }

            // Log received data (for testing)
            Console.WriteLine($"Received File: {bl.FileName}");
            Console.WriteLine($"Company: {company}");
            Console.WriteLine($"Import Request Number: {impReqNumber}");

            // TODO: Save file or process it as needed

            return Ok(new
            {
                message = "Upload successful!",
                fileName = bl.FileName,
                company,
                impReqNumber
            });
        }
    }
}
