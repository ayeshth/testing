namespace ImportProcess.Models
{
    public class BOCBankRecord
    {
        public string Date { get; set; } = "";
        public string? SourceDocNo { get; set; }
        public decimal Amount { get; set; }
        public string? AmountStatus { get; set; }
    }
}
