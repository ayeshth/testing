using ClosedXML.Excel;
using ImportProcess.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ImportProcess.Services
{
    public class SeylanBankStatementService : ISeylanBankStatementService
    {
        private readonly ILogger<SeylanBankStatementService> _logger;

        public SeylanBankStatementService(ILogger<SeylanBankStatementService> logger)
        {
            _logger = logger;
        }

        public async Task<List<SeylanBankTransaction>> ExtractTransactionsAsync(IFormFile file)
        {
            var transactions = new List<SeylanBankTransaction>();

            if (file == null || file.Length == 0)
                throw new ArgumentException("Invalid file");

            if (!IsExcelFile(file))
                throw new Exception("Seylan bank requires Excel file (.xlsx, .xls)");

            try
            {
                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    stream.Position = 0;

                    using (var workbook = new XLWorkbook(stream))
                    {
                        if (workbook.Worksheets.Count == 0)
                            throw new Exception("Excel file contains no worksheets");

                        var worksheet = workbook.Worksheet(1);

                        int headerRow = FindHeaderRow(worksheet);

                        if (headerRow == -1)
                            throw new Exception("Could not find header row with 'Transaction Date'. Please check the Excel format.");

                        int row = headerRow + 1;
                        int processedCount = 0;

                        while (!worksheet.Cell(row, 1).IsEmpty() && row < 10000)
                        {
                            try
                            {
                                var transaction = ParseTransactionRow(worksheet, row);
                                if (transaction != null)
                                {
                                    transactions.Add(transaction);
                                    processedCount++;
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning("Error processing row {Row}: {Error}", row, ex.Message);
                            }
                            row++;
                        }

                        _logger.LogInformation("Processed {Count} transactions from Seylan Excel", processedCount);
                    }
                }

                return transactions;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing Seylan Excel file: {FileName}", file.FileName);
                throw new Exception($"Error processing Excel file: {ex.Message}");
            }
        }

        private int FindHeaderRow(IXLWorksheet worksheet)
        {
            for (int r = 1; r <= 20; r++)
            {
                var cellText = worksheet.Cell(r, 1).GetString().Trim();
                if (string.Equals(cellText, "Transaction Date", StringComparison.OrdinalIgnoreCase))
                    return r;
            }
            return -1;
        }

        private SeylanBankTransaction ParseTransactionRow(IXLWorksheet worksheet, int row)
        {
            var dateCell = worksheet.Cell(row, 1);

            DateTime txnDate;

            if (dateCell.DataType == XLDataType.Number)
            {
                txnDate = DateTime.FromOADate(dateCell.GetDouble());
            }
            else
            {
                string dateText = dateCell.GetString().Trim();
                if (!DateTime.TryParseExact(dateText, "d/M/yyyy", 
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out txnDate))
                {
                    _logger.LogWarning("Row {Row}: Invalid date format '{DateText}'", row, dateText);
                    return null;
                }
            }

            string sourceDocNo = worksheet.Cell(row, 4).GetString().Trim();
            string amountStatus = worksheet.Cell(row, 6).GetString().Trim();
            string amountText = worksheet.Cell(row, 8).GetString().Trim().Replace(",", "");

            if (!decimal.TryParse(amountText, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal amount))
            {
                _logger.LogWarning("Row {Row}: Invalid amount '{AmountText}'", row, amountText);
                amount = 0m;
            }

            return new SeylanBankTransaction
            {
                TxnDate = txnDate.ToString("yyyy-MM-dd"), // formatted string
                SourceDocNo = sourceDocNo,
                AmountStatus = amountStatus,
                Amount = amount
            };
        }

        private bool IsExcelFile(IFormFile file)
        {
            var allowedExtensions = new[] { ".xlsx", ".xls" };
            var fileExtension = Path.GetExtension(file.FileName).ToLower();
            return allowedExtensions.Contains(fileExtension);
        }
    }
}
