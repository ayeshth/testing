using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using ImportProcess.Models;

namespace ImportProcess.Services
{
    public interface IBOCBankStatementService
    {
        Task<List<BOCBankRecord>> ExtractAsync(IFormFile file);
    }
}
