using ImportProcess.Models;

namespace ImportProcess.Services
{
    public interface IAzureOcrService
    {
        Task<List<BankStatementRecord>> ExtractBankStatementAsync(IFormFile imageFile);
    }
}
