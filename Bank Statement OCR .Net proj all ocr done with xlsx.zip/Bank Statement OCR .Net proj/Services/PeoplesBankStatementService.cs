using ClosedXML.Excel;
using ImportProcess.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ImportProcess.Services
{
    public class PeoplesBankStatementService : IPeoplesBankStatementService
    {
        public async Task<List<PeoplesBankTransaction>> ExtractTransactionsAsync(IFormFile file)
        {
            var transactions = new List<PeoplesBankTransaction>();

            if (file == null || file.Length == 0)
                throw new ArgumentException("Invalid file");

            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);
                stream.Position = 0;

                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(1);
                    var lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 1;

                    int headerRow = -1;
                    for (int r = 1; r <= lastRow; r++)
                    {
                        var firstCell = worksheet.Cell(r, 1).GetString().Trim();
                        if (string.Equals(firstCell, "Date", StringComparison.OrdinalIgnoreCase))
                        {
                            headerRow = r;
                            break;
                        }
                    }

                    if (headerRow == -1)
                        throw new Exception("Could not find header row containing 'Date'");

                    // Map header names to column indexes
                    var headers = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                    int lastColumn = worksheet.LastColumnUsed().ColumnNumber();
                    for (int c = 1; c <= lastColumn; c++)
                    {
                        string header = worksheet.Cell(headerRow, c).GetString().Trim();
                        if (!string.IsNullOrEmpty(header))
                            headers[header] = c;
                    }

                    if (!headers.ContainsKey("Date") || !headers.ContainsKey("Description") ||
                        !headers.ContainsKey("Debits") || !headers.ContainsKey("Credits"))
                        throw new Exception("Required columns not found in header");

                    int row = headerRow + 1;
                    while (row <= lastRow)
                    {
                        var dateCell = worksheet.Cell(row, headers["Date"]);
                        if (dateCell.IsEmpty())
                        {
                            row++;
                            continue;
                        }

                        try
                        {
                            // Parse date
                            DateTime txnDate;
                            if (dateCell.DataType == XLDataType.DateTime)
                                txnDate = dateCell.GetDateTime();
                            else if (dateCell.DataType == XLDataType.Number)
                                txnDate = DateTime.FromOADate(dateCell.GetDouble());
                            else
                            {
                                if (!DateTime.TryParseExact(dateCell.GetString().Trim(),
                                    new[] { "dd/MM/yyyy", "d/M/yyyy", "dd-MM-yyyy", "d-M-yyyy", "MM/dd/yyyy", "M/d/yyyy" },
                                    CultureInfo.InvariantCulture, DateTimeStyles.None, out txnDate))
                                {
                                    row++;
                                    continue;
                                }
                            }

                            // SourceDocNo
                            string sourceDocNo = worksheet.Cell(row, headers["Description"]).GetString().Trim();
                            if (string.IsNullOrEmpty(sourceDocNo))
                            {
                                row++;
                                continue;
                            }

                            // Amount
                            string debitText = worksheet.Cell(row, headers["Debits"]).GetString().Trim().Replace(",", "");
                            string creditText = worksheet.Cell(row, headers["Credits"]).GetString().Trim().Replace(",", "");

                            decimal amount = 0m;
                            string amountStatus = "";

                            if (!string.IsNullOrEmpty(debitText) && decimal.TryParse(debitText, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal debitAmount))
                            {
                                amount = debitAmount;
                                amountStatus = "DR";
                            }
                            else if (!string.IsNullOrEmpty(creditText) && decimal.TryParse(creditText, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal creditAmount))
                            {
                                amount = creditAmount;
                                amountStatus = "CR";
                            }
                            else
                            {
                                row++;
                                continue;
                            }

                            transactions.Add(new PeoplesBankTransaction
                            {
                                Date = txnDate.ToString("yyyy-MM-dd"),
                                SourceDocNo = sourceDocNo,
                                Amount = amount,
                                AmountStatus = amountStatus
                            });
                        }
                        catch
                        {
                            // Skip invalid rows
                        }

                        row++;
                    }
                }
            }

            return transactions;
        }
    }
}
