using Microsoft.AspNetCore.Mvc;
using AzureFormRecognizerApp.Services;

namespace AzureFormRecognizerApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DocumentAnalysisController : ControllerBase
    {
        private readonly IFormRecognizerService _formRecognizerService;
        private readonly ILogger<DocumentAnalysisController> _logger;

        public DocumentAnalysisController(
            IFormRecognizerService formRecognizerService,
            ILogger<DocumentAnalysisController> logger)
        {
            _formRecognizerService = formRecognizerService;
            _logger = logger;
        }

        [HttpPost("analyze-invoice")]
        public async Task<IActionResult> AnalyzeInvoice(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded");

            if (!IsValidFileType(file))
                return BadRequest("Invalid file type. Only PDF and DOC files are supported");

            try
            {
                var result = await _formRecognizerService.AnalyzeInvoiceAsync(file);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing invoice analysis");
                return StatusCode(500, "Error processing document");
            }
        }

        [HttpPost("analyze-document")]
        public async Task<IActionResult> AnalyzeDocument(IFormFile file, [FromQuery] string modelId = "prebuilt-read")
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded");

            if (!IsValidFileType(file))
                return BadRequest("Invalid file type. Only PDF and DOC files are supported");

            try
            {
                var result = await _formRecognizerService.AnalyzeDocumentAsync(file, modelId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing document analysis");
                return StatusCode(500, "Error processing document");
            }
        }

        [HttpPost("extract-tables")]
        public async Task<IActionResult> ExtractTables(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded");

            if (!IsValidFileType(file))
                return BadRequest("Invalid file type. Only PDF and DOC files are supported");

            try
            {
                var tables = await _formRecognizerService.ExtractTablesAsync(file);
                return Ok(new { Tables = tables });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error extracting tables");
                return StatusCode(500, "Error processing document");
            }
        }

        private static bool IsValidFileType(IFormFile file)
        {
            var allowedExtensions = new[] { ".pdf", ".doc", ".docx" };
            var fileExtension = Path.GetExtension(file.FileName).ToLowerInvariant();
            return allowedExtensions.Contains(fileExtension);
        }
    }
}