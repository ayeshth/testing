using Microsoft.AspNetCore.Http;
using ImportProcess.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ImportProcess.Services
{
    public interface ICommercialBankStatementService
    {
        Task<List<CommercialBankRecord>> ExtractAsync(IFormFile pdfFile);
    }
}
