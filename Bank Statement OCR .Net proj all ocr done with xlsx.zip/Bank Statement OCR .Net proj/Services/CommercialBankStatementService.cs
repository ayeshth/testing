using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using ImportProcess.Models;
using AzureFormRecognizerApp.Services;

namespace ImportProcess.Services
{
    public class CommercialBankStatementService : ICommercialBankStatementService
    {
        private readonly IFormRecognizerService _ocr;
        private readonly ILogger<CommercialBankStatementService> _logger;

        public CommercialBankStatementService(IFormRecognizerService ocr, ILogger<CommercialBankStatementService> logger)
        {
            _ocr = ocr;
            _logger = logger;
        }

        public async Task<List<CommercialBankRecord>> ExtractAsync(IFormFile pdfFile)
        {
            // Extract tables from PDF via Azure Form Recognizer
            var tables = await _ocr.ExtractTablesAsync(pdfFile);

            var records = new List<CommercialBankRecord>();

            foreach (var table in tables)
            {
                if (table.Count == 0) continue;

                // Locate the header row
                int headerRowIdx = -1;
                for (int r = 0; r < table.Count; r++)
                {
                    var rowNorm = table[r].Select(c => NormalizeHeader(c ?? "")).ToList();
                    if (rowNorm.Any(x => x == "DATE") &&
                        rowNorm.Any(x => x == "PARTICULARS") &&
                        (rowNorm.Any(x => x == "RECEIPTS") || rowNorm.Any(x => x == "PAYMENTS")))
                    {
                        headerRowIdx = r;
                        break;
                    }
                }
                if (headerRowIdx < 0) continue;

                var header = table[headerRowIdx].Select(c => (c ?? "").Trim()).ToList();
                int colDate = FindCol(header, "DATE");
                int colPart = FindCol(header, "PARTICULARS");
                int colReceipts = FindCol(header, "RECEIPTS");
                int colPayments = FindCol(header, "PAYMENTS");

                string? carryDateIso = null;
                CommercialBankRecord? lastRecord = null;

                for (int r = headerRowIdx + 1; r < table.Count; r++)
                {
                    var row = table[r];

                    string dateRaw = GetCell(row, colDate);
                    string particulars = GetCell(row, colPart);
                    string receiptsRaw = GetCell(row, colReceipts);
                    string paymentsRaw = GetCell(row, colPayments);

                    // ✅ Always initialize variables
                    decimal recAmt = 0m;
                    decimal payAmt = 0m;

                    bool hasReceipt = TryParseAmount(receiptsRaw, out recAmt);
                    bool hasPayment = TryParseAmount(paymentsRaw, out payAmt);
                    bool hasAnyAmount = hasReceipt || hasPayment;

                    bool hasDate = TryParseDate(dateRaw, out var dateIso);
                    if (hasDate) carryDateIso = dateIso;

                    // Append continuation lines to last record
                    if (!hasAnyAmount && !hasDate && !string.IsNullOrWhiteSpace(particulars) && lastRecord != null)
                    {
                        lastRecord.ParticularsRaw = (lastRecord.ParticularsRaw + " " + CleanSpaces(particulars)).Trim();
                        lastRecord.ParticularsTag = DetectTag(lastRecord.ParticularsRaw);
                        continue;
                    }

                    // Add new transaction row
                    if (hasAnyAmount)
                    {
                        var rec = new CommercialBankRecord
                        {
                            Date = carryDateIso ?? (hasDate ? dateIso : ""),
                            SourceDocNo = null,
                            Amount = recAmt > 0 ? recAmt : payAmt,
                            AmountStatus = recAmt > 0 ? "CR" : "DR",
                            ParticularsRaw = CleanSpaces(particulars),
                        };
                        rec.ParticularsTag = DetectTag(rec.ParticularsRaw);

                        records.Add(rec);
                        lastRecord = rec;
                    }
                }
            }

            return records;
        }

        // --- Helpers ---

        private static string GetCell(List<string> row, int idx)
            => (idx >= 0 && idx < row.Count) ? (row[idx] ?? "").Trim() : "";

        private static int FindCol(List<string> header, string target)
        {
            for (int i = 0; i < header.Count; i++)
            {
                if (NormalizeHeader(header[i]) == target) return i;
            }
            return -1;
        }

        private static string NormalizeHeader(string? s)
        {
            s ??= "";
            s = Regex.Replace(s, @"\s+", " ").Trim();
            s = s.Replace("’", "'").Replace("‘", "'").Replace("`", "'");
            s = s.ToUpperInvariant().Replace(":", "").Replace(".", "");
            return s;
        }

        private static bool TryParseDate(string input, out string iso)
        {
            iso = "";
            if (string.IsNullOrWhiteSpace(input)) return false;

            var s = input.Trim().ToUpperInvariant();

            // e.g. 01AUG25
            var m = Regex.Match(s, @"^(?<d>\d{2})(?<mon>[A-Z]{3})(?<y>\d{2})$");
            if (m.Success)
            {
                var day = int.Parse(m.Groups["d"].Value);
                var year = 2000 + int.Parse(m.Groups["y"].Value);
                var monStr = m.Groups["mon"].Value;
                if (DateTime.TryParseExact($"{day}-{monStr}-{year}", "dd-MMM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
                {
                    iso = dt.ToString("yyyy-MM-dd");
                    return true;
                }
            }

            // dd/MM/yyyy or dd/MM/yy formats
            string[] formats = { "dd/MM/yyyy", "dd/MM/yy", "dd-MMM-yyyy", "dd-MMM-yy" };
            if (DateTime.TryParseExact(s, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt2))
            {
                iso = dt2.ToString("yyyy-MM-dd");
                return true;
            }

            if (DateTime.TryParse(s, out var dt3))
            {
                iso = dt3.ToString("yyyy-MM-dd");
                return true;
            }
            return false;
        }

        private static bool TryParseAmount(string input, out decimal value)
        {
            value = 0m;
            if (string.IsNullOrWhiteSpace(input)) return false;

            var s = input.Replace(",", "").Trim();
            s = Regex.Replace(s, @"[^0-9\.\-]", "");

            if (decimal.TryParse(s, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out var v))
            {
                value = v;
                return v != 0m;
            }
            return false;
        }

        private static string CleanSpaces(string s)
            => Regex.Replace(s ?? "", @"\s+", " ").Trim();

        private static string DetectTag(string? particulars)
        {
            if (string.IsNullOrWhiteSpace(particulars)) return "";
            var p = particulars.ToUpperInvariant();
            if (p.Contains("CASH DEPOSIT")) return "CASH DEPOSIT";
            if (p.Contains("DIRECT DEPOSIT")) return "DIRECT DEPOSIT";
            return "";
        }
    }
}
