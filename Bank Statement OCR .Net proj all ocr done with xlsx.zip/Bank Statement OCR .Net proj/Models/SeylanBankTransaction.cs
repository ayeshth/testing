namespace ImportProcess.Models
{
    public class SeylanBankTransaction
    {
        public string TxnDate { get; set; } // now string instead of DateTime
        public string SourceDocNo { get; set; }
        public decimal Amount { get; set; }
        public string AmountStatus { get; set; } // CR or DR
    }
}
