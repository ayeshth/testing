namespace ImportProcess.Models
{
    public class CommercialBankRecord
    {
        public string Date { get; set; } = "";         // yyyy-MM-dd
        public string? SourceDocNo { get; set; } = null; // kept null as requested
        public decimal Amount { get; set; } = 0m;
        public string AmountStatus { get; set; } = "";   // CR / DR
        public string ParticularsTag { get; set; } = ""; // CASH DEPOSIT / DIRECT DEPOSIT / ""
        // (Optional) Keep the full particulars if you ever need it:
        public string? ParticularsRaw { get; set; }
    }
}
