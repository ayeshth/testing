using System;

namespace ImportProcess.Models
{
    public class BankStatement
    {
        public DateTime? Date { get; set; }
        public string DocumentNumber { get; set; }
        public string Description { get; set; }
        public decimal Debit { get; set; }
        public decimal Credit { get; set; }
        public decimal Balance { get; set; }
    }
}
