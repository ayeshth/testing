using Microsoft.AspNetCore.Http;
using ImportProcess.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ImportProcess.Services
{
    public interface ISeylanBankStatementService
    {
        Task<List<SeylanBankTransaction>> ExtractTransactionsAsync(IFormFile file);
    }
}
