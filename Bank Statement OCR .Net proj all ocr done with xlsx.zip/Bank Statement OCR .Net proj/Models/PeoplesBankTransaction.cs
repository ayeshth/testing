using System;

namespace ImportProcess.Models
{
    public class PeoplesBankTransaction
    {
        public string Date { get; set; }
        public string SourceDocNo { get; set; } = "";
        public decimal Amount { get; set; }
        public string AmountStatus { get; set; } = ""; // "DR" or "CR"
    }
}
